package com.iti.presentation.screens.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import com.iti.presentation.ui.theme.LocalDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.iti.presentation.R
import com.iti.presentation.components.BottomNavItem
import com.iti.presentation.components.ProfileTabContent
import com.iti.presentation.components.WishlistTabContent
import com.iti.presentation.components.UnauthorizedDialog
import com.iti.presentation.components.ShopIQSnackBarHost
import com.iti.presentation.components.ShopIQSnackbarType
import com.iti.presentation.components.showError
import com.iti.presentation.components.showSuccess
import com.iti.presentation.screens.ai.AiChatScreen
import com.iti.presentation.screens.category.CategoryScreen
import com.iti.presentation.screens.home.components.HomeTabContent
import com.iti.presentation.screens.home.viewmodel.CartBadgeViewModel
import com.iti.presentation.screens.home.viewmodel.HomeViewModel
import com.iti.presentation.screens.profile.AccountSettingsScreen
import com.iti.presentation.screens.profile.ProfileViewModel
import com.iti.presentation.util.NetworkMonitor
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.koinInject

@Composable
fun HomeScreen(
    onNavigateToAllBrands: () -> Unit,
    onNavigateToAllProducts: (brandName: String?, subCategoryName: String?, displayTitle: String?) -> Unit,
    onCartClick: () -> Unit,
    onCategoryClick: (categoryId: String, categoryTitle: String) -> Unit,
    onNavigateToProduct: (Long) -> Unit,
    onLogout: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToOrders: () -> Unit,
    onNavigateToAiHistory: () -> Unit,
    onNavigateToEditProfile: () -> Unit,
    onNavigateToLocalizationCurrency: () -> Unit,
    onNavigateToAddressManagement: () -> Unit,
    profileViewModel: ProfileViewModel,
    viewModel: HomeViewModel = koinViewModel()
) {
    val context = LocalContext.current
    var selectedIndex by rememberSaveable { mutableIntStateOf(0) }
    val state by viewModel.state.collectAsState()
    var showAuthDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.effect.collect { effect ->
            when (effect) {
                is HomeContract.Effect.NavigateToAllBrands -> {
                    onNavigateToAllBrands()
                }

                HomeContract.Effect.NavigateToAllProducts -> {
                    onNavigateToAllProducts(null, null, null)
                }

                is HomeContract.Effect.NavigateToProduct -> {
                    onNavigateToProduct(effect.productId)
                }

                is HomeContract.Effect.NavigateToProducts -> {
                    onNavigateToAllProducts(effect.brandName, effect.subCategoryName, effect.displayTitle)
                }

                HomeContract.Effect.NavigateToSearch -> {
                    onNavigateToSearch()
                }

                HomeContract.Effect.NavigateToSignIn -> {
                    onLogout()
                }
                HomeContract.Effect.ShowAuthRequired -> {
                    showAuthDialog = true
                }

                HomeContract.Effect.NavigateToAiChat -> {
                    selectedIndex = 2 // AI tab index
                }

                is HomeContract.Effect.ShowToast -> {
                    if (effect.type == ShopIQSnackbarType.Success) {
                        snackbarHostState.showSuccess(effect.message.resolve(context))
                    } else {
                        snackbarHostState.showError(effect.message.resolve(context))
                    }
                }
            }
        }
    }

    HomeScreenContent(
        state = state,
        onNavigateToProduct = onNavigateToProduct,
        onIntent = viewModel::sendIntent,
        onLogout = { viewModel.sendIntent(HomeContract.Intent.Logout) },
        onCartClick = onCartClick,
        onCategoryClick = onCategoryClick,
        onNavigateToAiHistory = onNavigateToAiHistory,
        selectedIndex = selectedIndex,
        onSelectedIndexChanged = { selectedIndex = it },
        onNavigateToOrders = onNavigateToOrders,
        onNavigateToEditProfile = onNavigateToEditProfile,
        onNavigateToLocalizationCurrency = onNavigateToLocalizationCurrency,
        onNavigateToAddressManagement = onNavigateToAddressManagement,
        profileViewModel = profileViewModel,
        snackbarHostState = snackbarHostState
    )

    if (showAuthDialog) {
        UnauthorizedDialog(
            onDismiss = { showAuthDialog = false },
            onLogin = {
                showAuthDialog = false
                onLogout()
            }
        )
    }
}

@Composable
fun HomeScreenContent(
    state: HomeContract.State,
    onIntent: (HomeContract.Intent) -> Unit,
    onNavigateToProduct: (Long) -> Unit,
    onNavigateToOrders: () -> Unit,
    onCategoryClick: (categoryId: String, categoryTitle: String) -> Unit,
    onLogout: () -> Unit,
    onCartClick: () -> Unit,
    onNavigateToAiHistory: () -> Unit,
    selectedIndex: Int,
    onSelectedIndexChanged: (Int) -> Unit,
    onNavigateToEditProfile: () -> Unit,
    onNavigateToLocalizationCurrency: () -> Unit,
    onNavigateToAddressManagement: () -> Unit,
    profileViewModel: ProfileViewModel,
    snackbarHostState: SnackbarHostState = remember { SnackbarHostState() },
    networkMonitor: NetworkMonitor = koinInject(),
    cartBadgeViewModel: CartBadgeViewModel = koinViewModel()
) {
    val isConnected by networkMonitor.isConnected.collectAsState(initial = networkMonitor.isCurrentlyConnected())
    var wasConnected by remember { mutableStateOf(isConnected) }
    val connectionLostMessage = stringResource(id = R.string.network_connection_lost)

    val cartItemCount by cartBadgeViewModel.cartItemCount.collectAsState()

    LaunchedEffect(isConnected) {
        if (!isConnected && wasConnected) {
            if (state.screenState is HomeContract.ScreenState.Success) {
                snackbarHostState.showError(connectionLostMessage)
            }
        }
        wasConnected = isConnected
    }

    val navItems = BottomNavItem.entries

    BackHandler(enabled = selectedIndex != 0) {
        onSelectedIndexChanged(0)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (navItems[selectedIndex] != BottomNavItem.AI) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.background,
                        tonalElevation = 0.dp
                    ) {

                        navItems.forEachIndexed { index, item ->
                            val isSelected = selectedIndex == index
                            if (item == BottomNavItem.AI) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(80.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val isDark = LocalDarkTheme.current
                                    val bgColor = if (isSelected) {
                                        if (isDark) Color(0xFF3B1E78) else Color(0xFFE8DDFF)
                                    } else {
                                        if (isDark) Color(0xFF242A31) else Color(0xFFF3F4F6)
                                    }
                                    val iconColor = if (isSelected) {
                                        if (isDark) Color(0xFFD4BFFF) else Color(0xFF6F32E5)
                                    } else {
                                        if (isDark) Color(0xFF8D97A5) else Color(0xFF8E8E93)
                                    }

                                    Box(
                                        modifier = Modifier.offset(y = (-8).dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(68.dp)
                                                .background(
                                                    color = if (isSelected) Color(0xFF6F32E5).copy(alpha = 0.12f) else Color.Transparent,
                                                    shape = CircleShape
                                                )
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .shadow(
                                                    elevation = if (isSelected) 8.dp else 0.dp,
                                                    shape = CircleShape,
                                                    ambientColor = Color(0xFF6F32E5),
                                                    spotColor = Color(0xFF6F32E5)
                                                )
                                                .background(
                                                    brush = if (isDark) {
                                                        if (isSelected) {
                                                            Brush.linearGradient(listOf(Color(0xFF3B1E78), Color(0xFF2C145C)))
                                                        } else {
                                                            Brush.linearGradient(listOf(Color(0xFF2A1B4E), Color(0xFF20103E)))
                                                        }
                                                    } else {
                                                        if (isSelected) {
                                                            Brush.linearGradient(listOf(Color(0xFFF0E8FF), Color(0xFFE8DDFF)))
                                                        } else {
                                                            Brush.linearGradient(listOf(Color(0xFFF6F1FF), Color(0xFFECE0FF)))
                                                        }
                                                    },
                                                    shape = CircleShape
                                                )
                                                .clickable {
                                                    onSelectedIndexChanged(index)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                painter = painterResource(id = item.iconResId!!),
                                                contentDescription = stringResource(id = item.labelResId),
                                                tint = if (isDark) {
                                                    if (isSelected) Color(0xFFD4BFFF) else Color(0xFF9E80E5)
                                                } else {
                                                    if (isSelected) Color(0xFF6F32E5) else Color(0xFF8C52FF)
                                                },
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }

                                    if (isSelected) {
                                        Canvas(
                                            modifier = Modifier
                                                .align(Alignment.BottomCenter)
                                                .padding(bottom = 6.dp)
                                                .size(8.dp, 6.dp)
                                        ) {
                                            val path = Path().apply {
                                                moveTo(size.width / 2f, 0f)
                                                lineTo(size.width, size.height)
                                                lineTo(0f, size.height)
                                                close()
                                            }
                                            drawPath(
                                                path = path,
                                                color = if (isDark) Color(0xFFD4BFFF) else Color(0xFF6F32E5)
                                            )
                                        }
                                    }
                                }
                            } else {
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        onSelectedIndexChanged(index)
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) item.selectedIcon!! else item.unselectedIcon!!,
                                            contentDescription = stringResource(id = item.labelResId)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = stringResource(id = item.labelResId),
                                            maxLines = 1,
                                            softWrap = false,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 11.sp
                                            )
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onBackground,
                                        selectedTextColor = MaterialTheme.colorScheme.onBackground,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = Color.Transparent
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->

            when (navItems[selectedIndex]) {

                BottomNavItem.Home -> {
                    HomeTabContent(
                        state = state,
                        onIntent = onIntent,
                        bottomPadding = padding.calculateBottomPadding(),
                        cartItemCount = cartItemCount,
                        onCartClick = onCartClick
                    )
                }

                BottomNavItem.Category -> {
                    CategoryScreen(
                        viewModel = koinViewModel(),
                        bottomPadding = padding.calculateBottomPadding(),
                        cartItemCount = cartItemCount,
                        onCartClick = onCartClick,
                        onCategoryClick = onCategoryClick,
                    )
                }

                BottomNavItem.AI -> {
                    AiChatScreen(
                        onBackClick = { onSelectedIndexChanged(0) },
                        onHistoryClick = onNavigateToAiHistory,
                        currentUser = state.currentUser,
                        onAuthClick = onLogout,
                        bottomPadding = 0.dp,
                        onNavigateToProduct = onNavigateToProduct
                    )
                }

                BottomNavItem.Wishlist -> {
                    WishlistTabContent(
                        onProductClick = { productId ->
                            val idLong = productId.substringAfterLast("/").toLongOrNull() ?: 0L
                            onNavigateToProduct(idLong)
                        },
                        onExploreClick = { onSelectedIndexChanged(0) },
                        onAuthClick = onLogout,
                        cartItemCount = cartItemCount,
                        onCartClick = onCartClick
                    )
                }

                BottomNavItem.Profile -> {
                    AccountSettingsScreen(
                        viewModel = profileViewModel,
                        onNavigateBack = { onSelectedIndexChanged(0) },
                        onLogout = onLogout,
                        onNavigateToEditProfile = onNavigateToEditProfile,
                        onNavigateToLocalizationCurrency = onNavigateToLocalizationCurrency,
                        onNavigateToAddressManagement = onNavigateToAddressManagement,
                        onNavigateToOrders = onNavigateToOrders,
                        bottomPadding = padding.calculateBottomPadding()
                    )
                }
            }
        }

        ShopIQSnackBarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 4.dp)
        )
    } // end outer Box
}